package ast;

/**
 * @author Matteo Schirinzi 20035542
 */
public abstract class NodeDecSt extends NodeAST{

}
